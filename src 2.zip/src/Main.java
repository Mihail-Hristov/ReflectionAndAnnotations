import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static class ComparatorByName implements Comparator<Method> {

        @Override
        public int compare(Method o1, Method o2) {
            return o1.getName().compareTo(o2.getName());
        }
    }

    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {

        Class<Reflection> reflection = Reflection.class;
        /*System.out.println(reflection);

        Class<?> superclass = reflection.getSuperclass();

        System.out.println(superclass);

        Class<?>[] interfaces = reflection.getInterfaces();

        for (Class<?> aInterfaces : interfaces) {
            System.out.println(aInterfaces);
        }

        Reflection reflectionObject = reflection.getDeclaredConstructor().newInstance();

        System.out.println(reflectionObject);*/

        Set<Method> getters = new TreeSet<>(new ComparatorByName());

        Set<Method> setters = new TreeSet<>(new ComparatorByName());


        Arrays.stream(reflection.getDeclaredMethods())
                .filter(g -> g.getName().startsWith("get") && g.getParameterCount() == 0)
                .forEach(g -> getters.add(g));

        Arrays.stream(reflection.getDeclaredMethods()).
                filter(s -> s.getName().startsWith("set") && s.getParameterCount() == 1)
                .collect(Collectors.toList())
                .forEach(s -> setters.add(s));

        for (Method method : getters) {
            System.out.println(String.format("%s will return class %s"
                    , method.getName()
                    , method.getReturnType().getName()));
        }

        for (Method method : setters) {
            System.out.println(String.format("%s and will set field of class %s"
                    , method.getName()
                    , method.getParameterTypes()[0].getName()));
        }
    }
}
