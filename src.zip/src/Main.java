import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {


        Class<Reflection> reflection = Reflection.class;
        System.out.println(reflection);

        Class<?> superclass = reflection.getSuperclass();

        System.out.println(superclass);

        Class<?>[] interfaces = reflection.getInterfaces();

        for (Class<?> aInterfaces : interfaces) {
            System.out.println(aInterfaces);
        }

        Reflection reflectionObject = reflection.getDeclaredConstructor().newInstance();

        System.out.println(reflectionObject);
    }
}
